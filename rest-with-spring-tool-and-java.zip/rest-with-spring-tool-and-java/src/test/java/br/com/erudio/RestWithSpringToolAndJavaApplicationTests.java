package br.com.erudio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestWithSpringToolAndJavaApplicationTests {

	@Test
	void contextLoads() {
	}

}
